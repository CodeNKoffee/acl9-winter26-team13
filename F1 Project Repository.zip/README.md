# Formula 1 Podium Prediction Companion (Milestone 1)

Predict whether a driver finishes on the podium (top 3) **using only information available after qualifying / once the grid is set**, plus three data-engineering questions answered with the same cleaned data.

Data: Kaggle *Formula 1 World Championship (1950 – 2024)* — `rohanrao/formula-1-world-championship-1950-2020` (14 CSV tables).

## Contents
| Path | What it is |
|---|---|
| `f1_podium_prediction.ipynb` | The single run-all notebook (audit → cleaning → EDA before/after → Q1–Q3 → features & leakage tests → feature selection → temporal split → preprocessing-order experiments → models → ablation → XAI → inference function) |
| `report/F1_Podium_Prediction_Report.pdf` | Analytical report (answers to Q1–Q3 with figures, selected features and why they are valid pre-race, model comparison, ablation, XAI, limitations) |
| `outputs/modeling_table.csv` | Unique driver–race modelling table (one row per driver per race, 31 features + label + split) |
| `outputs/model_comparison_long.csv`, `model_comparison_wide.csv` | ROC-AUC, PR-AUC, F1, precision, recall on train / validation / test for every model |
| `outputs/ablation_results.csv` | Feature-group ablation (LR, LightGBM, NN) |
| `outputs/feature_documentation.csv` | Every feature: group, definition, why it is valid before the race |
| `outputs/results.json` | All numbers used in the report |
| `outputs/figures/` | All EDA / result plots (34 PNG) |
| `outputs/primary_pipeline.joblib` | Fitted preprocessing + primary model + threshold |

## How to run
**Kaggle:** create a notebook, upload `f1_podium_prediction.ipynb`, *Add data* → `Formula 1 World Championship (1950 - 2020)`, turn **Internet on** (the first cell `pip install`s `lime` if missing), *Run All* (~8–10 min on CPU). Outputs are written to `/kaggle/working/outputs`.

**Local:** `pip install -r requirements.txt`, download the dataset CSVs into `./input/` (e.g. `kagglehub.dataset_download('rohanrao/formula-1-world-championship-1950-2020')` and copy/symlink), then `jupyter nbconvert --to notebook --execute f1_podium_prediction.ipynb`. Outputs go to `./outputs`.

## Protocol (as specified in the brief / primer)
* Grain: one row per `(raceId, driverId)`; Indy 500 (1950–60) and DNQ/DNPQ rows excluded; shared-drive duplicates resolved by a documented rule; `grid == 0` kept with an explicit flag.
* Cutoff: after qualifying/grid is set. Features use only the race's own grid/qualifying plus strictly earlier races (leakage unit test + negative control in the notebook).
* Split: train ≤ 2019, validation 2020–21, test ≥ 2022 (chronological). Model selection uses validation only.
* Metrics: ROC-AUC, PR-AUC (primary), F1, precision, recall on train / validation / test.
* Explanations (permutation importance, SHAP, LIME) describe the model, **not causality**.

## Headline results
See the report. In short: starting position carries most of the signal; the tuned models (LR, Random Forest, LightGBM, shallow NN) are statistically indistinguishable on the 2022–24 test seasons.
