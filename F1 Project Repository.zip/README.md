# Formula 1 Podium Prediction Companion (Milestone 1)

ACL, Winter 2026, Team 13: Youssef Hesham, Hatem Soliman, Mohammed Elazab, Tony Makaryous

We predict whether a driver finishes on the podium (`positionOrder <= 3`) using only what is known after qualifying and before the race starts, and answer three data-engineering questions on the same cleaned data.

Data: Kaggle *Formula 1 World Championship (1950-2024)*, `rohanrao/formula-1-world-championship-1950-2020` (14 CSV tables).

## What's in here

| Path | What it is |
|---|---|
| `f1_podium_prediction.ipynb` | The single run-all notebook: audit, cleaning, EDA before/after, Q1-Q3, leakage-safe features, feature selection, split, preprocessing experiments, models, ablation, XAI, inference function |
| `report/F1_Podium_Prediction_Report.pdf` | Analytical report: Q1-Q3 answers with figures, the selected features and why each is valid before the race, model comparison, ablation, explanations, limitations |
| `outputs/modeling_table.csv` | The modelling table: one row per (raceId, driverId), the 21 features, the label and the split |
| `outputs/model_comparison.csv` | ROC-AUC, PR-AUC, F1, precision and recall on train / validation / test for every model |
| `outputs/preprocessing_experiments.csv` | Preprocessing-order experiments E1-E3 |
| `outputs/ablation_results.csv` | Feature-group ablation for logistic regression, gradient boosting and the neural net |
| `outputs/figures/` | Every plot in the notebook (29 PNG files) |
| `requirements.txt` | Library versions the notebook was run with |

## How to run

**Kaggle:** create a notebook, import `f1_podium_prediction.ipynb`, add the dataset `rohanrao/formula-1-world-championship-1950-2020` as input (we used version 24, which covers 1950-2024), turn Internet on (the first cell installs the pinned scikit-learn version and `lime`), then *Run All*. It takes a few minutes on CPU.

**Locally:** `pip install -r requirements.txt`, put the 14 CSV files in a folder called `data/` next to the notebook, then run all cells (or `jupyter nbconvert --to notebook --execute --inplace f1_podium_prediction.ipynb`).

Everything is seeded, so with the versions in `requirements.txt` you get exactly the numbers in the notebook and the report. Other library versions can move the scores slightly.

## Main choices

* One row per driver per race. The Indianapolis 500 (1950-60) and cars that failed to qualify are removed; shared drives keep the car the driver started in.
* Prediction cutoff: after qualifying. Features come from the race's own grid and qualifying, or from strictly earlier races (checked by recomputing features from scratch).
* Chronological split: train up to 2019, validation 2020-21, test 2022-24. The training window (2003-2019) and all hyperparameters and thresholds were chosen on validation only.
* Primary metric PR-AUC (podiums are only 13-15% of rows), secondary ROC-AUC, plus F1, precision and recall.

## Results in short

* Gradient boosting has the best validation PR-AUC (0.734) and reaches 0.711 on the 2022-24 test seasons, against 0.647 for the rule "top three on the grid". All learned models score between 0.686 and 0.720 on test, so the extra complexity doesn't clearly beat the logistic-regression baseline (0.720).
* The grid slot is by far the most important feature, followed by recent team results, the gap to pole and the team's best grid slot. These explanations describe the model, not what causes podiums.
* Q1: front-row conversion went from 65% to 74% after 2014 and the circuit ranking changed a lot (rho = 0.22). Q2: no home advantage once the grid slot is controlled. Q3: mechanical retirements fell from 9.2% to 5.7% of starts.
